PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE user (
	id INTEGER NOT NULL, 
	email VARCHAR(100) NOT NULL, 
	password VARCHAR(100) NOT NULL, 
	firstname VARCHAR(100), 
	lastname VARCHAR(100), 
	photo VARCHAR(200), 
	role VARCHAR(50), 
	permissions JSON, 
	PRIMARY KEY (id), 
	UNIQUE (email)
);
INSERT INTO user VALUES(1,'admin@gmail.com','$2b$12$OVPr6tt24xvFWOPJoTUF2ectkybU7lelkI6./dAMS5goAl5oBCJ7S','Principal','admin',NULL,'admin','["gestion_utilisateurs", "gestion_produits", "gestion_ventes", "gestion_banque", "gestion_caise", "gestion_depot", "voir_stock_depot", "voir_stock_boutique", "voir_stock_globale", "voir_benefice", "gestion_depenses_ordinaires", "gestion_depenses_recurentes", "voir_historique_vente", "gestion_transactions_stock_boutique"]');
CREATE TABLE produits (
	id INTEGER NOT NULL, 
	nom VARCHAR(100) NOT NULL, 
	description VARCHAR(200), 
	prix FLOAT NOT NULL, 
	prix_achat FLOAT NOT NULL, 
	quantite INTEGER NOT NULL, 
	quantite_depot INTEGER, 
	en_route INTEGER, 
	PRIMARY KEY (id)
);
INSERT INTO produits VALUES(1,'Cube bass martin audion','',350.0,205.0,19,0,0);
INSERT INTO produits VALUES(2,'Cube bass ev','',350.0,240.0,18,0,0);
CREATE TABLE factures (
	id INTEGER NOT NULL, 
	nom_client VARCHAR(100) NOT NULL, 
	montant_total FLOAT NOT NULL, 
	date_facture DATETIME, 
	paiement_credit BOOLEAN, 
	montant_cash FLOAT, 
	montant_credit FLOAT, 
	PRIMARY KEY (id)
);
INSERT INTO factures VALUES(1,'Rebecca',700.0,'2025-11-28 13:15:49.041062',0,700.0,0.0);
INSERT INTO factures VALUES(2,'Rebecca',350.0,'2025-11-30 03:29:51.565792',1,300.0,50.0);
CREATE TABLE depenses (
	id INTEGER NOT NULL, 
	description VARCHAR(200) NOT NULL, 
	montant FLOAT NOT NULL, 
	date_depense DATETIME, 
	categorie VARCHAR(100), 
	est_recurrente BOOLEAN, 
	frequence_recurrence VARCHAR(50), 
	PRIMARY KEY (id)
);
CREATE TABLE caisse (
	id INTEGER NOT NULL, 
	type_transaction VARCHAR(10) NOT NULL, 
	montant FLOAT NOT NULL, 
	description VARCHAR(200), 
	date_transaction DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE compte_bancaire (
	id INTEGER NOT NULL, 
	type_transaction VARCHAR(10) NOT NULL, 
	montant FLOAT NOT NULL, 
	description VARCHAR(200), 
	date_transaction DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE transactions_produit (
	id INTEGER NOT NULL, 
	produit_id INTEGER NOT NULL, 
	type VARCHAR(6) NOT NULL, 
	quantite INTEGER NOT NULL, 
	date_transaction DATETIME, 
	description TEXT, 
	PRIMARY KEY (id), 
	FOREIGN KEY(produit_id) REFERENCES produits (id)
);
INSERT INTO transactions_produit VALUES(1,1,'entree',20,'2025-11-28 13:15:07.517835','');
INSERT INTO transactions_produit VALUES(2,2,'entree',20,'2025-11-28 13:15:13.906643','');
CREATE TABLE paiements (
	id INTEGER NOT NULL, 
	facture_id INTEGER NOT NULL, 
	montant FLOAT NOT NULL, 
	date_paiement DATETIME NOT NULL, 
	description VARCHAR(200), 
	mode_paiement VARCHAR(50), 
	PRIMARY KEY (id), 
	FOREIGN KEY(facture_id) REFERENCES factures (id)
);
INSERT INTO paiements VALUES(1,1,200.0,'2025-11-28 14:16:31.104522','','cash');
INSERT INTO paiements VALUES(2,1,300.0,'2025-11-28 14:29:11.502301','','cash');
INSERT INTO paiements VALUES(3,2,100.0,'2025-11-30 04:32:02.864730','','cash');
CREATE TABLE ventes (
	id INTEGER NOT NULL, 
	produit_id INTEGER NOT NULL, 
	facture_id INTEGER NOT NULL, 
	quantite INTEGER NOT NULL, 
	montant_total FLOAT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(produit_id) REFERENCES produits (id), 
	FOREIGN KEY(facture_id) REFERENCES factures (id)
);
INSERT INTO ventes VALUES(1,2,1,1,350.0);
INSERT INTO ventes VALUES(2,1,1,1,350.0);
INSERT INTO ventes VALUES(3,2,2,1,350.0);
CREATE TABLE panier (
	id INTEGER NOT NULL, 
	produit_id INTEGER NOT NULL, 
	quantite INTEGER NOT NULL, 
	prix FLOAT NOT NULL, 
	session_id VARCHAR(100) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(produit_id) REFERENCES produits (id)
);
CREATE TABLE transaction_depot (
	id BIGINT NOT NULL, 
	produit_id INTEGER NOT NULL, 
	quantite INTEGER NOT NULL, 
	type_transaction VARCHAR(10) NOT NULL, 
	date_transaction DATETIME, 
	description TEXT, 
	PRIMARY KEY (id), 
	FOREIGN KEY(produit_id) REFERENCES produits (id)
);
CREATE TABLE produits_en_route (
	id INTEGER NOT NULL, 
	produit_id INTEGER NOT NULL, 
	quantite INTEGER NOT NULL, 
	prix_achat FLOAT, 
	date_commande DATETIME, 
	statut VARCHAR(50), 
	PRIMARY KEY (id), 
	FOREIGN KEY(produit_id) REFERENCES produits (id)
);
CREATE TABLE benefices (
	id INTEGER NOT NULL, 
	vente_id INTEGER NOT NULL, 
	montant_benefice FLOAT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(vente_id) REFERENCES ventes (id)
);
COMMIT;
