SAUVEGARDE DE LA BASE DE DONNÉES
================================

Date: 30/11/2025 14:39:43

Contenu du ZIP:
- backup_20251130_143943.db: Base de données au format SQLite
- backup_20251130_143943.sql: Dump SQL complète de la base de données

Comment restaurer:

1. À partir du fichier SQLite (.db):
   - Copier le fichier .db au même endroit que l'original

2. À partir du fichier SQL (.sql):
   - Ouvrir une invite de commande dans le dossier du fichier
   - Exécuter: sqlite3 nouvelle_base.db < backup_*.sql

Pour plus d'informations, consultez la documentation SQLite.
